XPperMinute = XPperMinute or class()

XPperMinute.save_path = SavePath .. "XPperMinute.json"
XPperMinute.mod_path = 'mods\\XPperMinute\\'
XPperMinute.ModOptions = XPperMinute.mod_path .. 'menu\\modoptions.txt'
XPperMinute.debugMode=false
XPperMinute.settings={}
XPperMinute.settings.X=0
XPperMinute.settings.Y=0
Hooks:Add("LocalizationManagerPostInit", "LocalizationManagerPostInit_XPperMinute", function(loc)
    for __, filename in pairs(file.GetFiles(XPperMinute.mod_path .. "menu\\")) do
		local str = filename:match('^(.*).json$')
		if str and Idstring(str) and Idstring(str):key() == SystemInfo:language():key() then
			loc:load_localization_file(XPperMinute.mod_path .. "menu\\" .. filename)
			break
		end
    end
	
    loc:load_localization_file(XPperMinute.mod_path .. "menu/english.json", false)
end)

local function AddModOptions(menu_manager)
    if menu_manager == nil then
		return
    end

    MenuCallbackHandler.callback_SetPositionX = function(self, item)
		
		XPperMinute.settings.X=item:value()
		if XPperMinute.text then
			XPperMinute.text:set_x(item:value())
		end
		XPperMinute:Save()
    end
	MenuCallbackHandler.callback_SetPositionY = function(self, item)
		
		XPperMinute.settings.Y=item:value()
		if XPperMinute.text then
			XPperMinute.text:set_y(item:value())
		end
		XPperMinute:Save()
    end
	MenuHelper:LoadFromJsonFile(XPperMinute.ModOptions, XPperMinute, XPperMinute.settings)
end

Hooks:Add("MenuManagerInitialize", "XPperMinute_AddModOptions", AddModOptions)

function XPperMinute:Init()
	BeardLib:RemoveUpdater("XPperMinute.Update")
	
	XPperMinute.totalValue=0
	XPperMinute.startTime=0
	XPperMinute.cooldown=1.5
	XPperMinute.GlobalCooldown=1
	XPperMinute.tempCooldown=0
	XPperMinute.tempGlobalCooldown=0
	XPperMinute.greenExp = 300000
	XPperMinute.redExp = 10000
	XPperMinute.yellowExp = (XPperMinute.greenExp + XPperMinute.redExp)/2
	XPperMinute.colorRed=255
	XPperMinute.colorGreen=0
	XPperMinute.colorNow=Color(255, 255, 0, 0) / 255
	XPperMinute.ColorExpAdded = Color(255, 154, 68, 220) / 255
	XPperMinute.yellowExp = XPperMinute.redExp + (XPperMinute.greenExp - XPperMinute.redExp) / 2
	XPperMinute.coef = 2*100/(XPperMinute.greenExp-XPperMinute.redExp)
end

function XPperMinute:Load()
    local file = io.open(XPperMinute.save_path, "r")
    if file then
        for key, value in pairs(json.decode(file:read("*all"))) do
                XPperMinute.settings[key] = value
        end
        file:close()

    end

end

function XPperMinute:Save()
    local file = io.open(XPperMinute.save_path, "w+")
    if file then
        file:write(json.encode(XPperMinute.settings))
        file:close()
    end
end

function XPperMinute:format_int(number)
	local i, j, minus, int, fraction = tostring(number):find('([-]?)(%d+)([.]?%d*)')
	if int then
		int = int:reverse():gsub("(%d%d%d)", "%1 ")
		return minus .. int:reverse():gsub("^,", "") .. fraction
	end
	return 0
end

function XPperMinute:Format(floatValue)
	local mod = math.modf(floatValue)
	return tostring(XPperMinute:format_int(mod)).. " xp/min"--string.format("%.2f xp/min", floatValue)
end

function XPperMinute:CalculateValue()
	return XPperMinute:get_current_total_xp()/((Application:time()-XPperMinute.startTime)/60)
end

function XPperMinute:Color(experience)
    if experience < XPperMinute.redExp then
        return Color.red
	elseif experience > XPperMinute.greenExp then
		return Color.green
    end
    if (experience <= XPperMinute.yellowExp) then
        return Color(1,experience*XPperMinute.coef/100,0)
    end
    return Color((XPperMinute.greenExp-experience)*XPperMinute.coef/100,1,0)

end

function XPperMinute:callback_SetPositionX()

end

function XPperMinute:callback_SetPositionY()

end

function XPperMinute:Update()
	local timeS = Application:time()
	if timeS > XPperMinute.tempGlobalCooldown then
		local staticExp = XPperMinute:get_current_total_xp()
		local experience = XPperMinute:CalculateValue(staticExp)
		XPperMinute.text:set_color(XPperMinute:Color(experience))
		if XPperMinute.totalValue < staticExp then
			XPperMinute.text:set_color(XPperMinute.ColorExpAdded)--Color.green
			XPperMinute.totalValue = staticExp
			--XPperMinute.tempCooldown= timeS + XPperMinute.cooldown
		end
		--if timeS >= XPperMinute.tempCooldown then
		--	XPperMinute.tempCooldown=0
		--Color.white
		--end
		
		XPperMinute.text:set_text(XPperMinute:Format(experience))
		XPperMinute.tempGlobalCooldown = timeS + XPperMinute.GlobalCooldown
	end
end

function XPperMinute:get_current_total_xp()
	if managers and managers.network and managers.network:session() and managers.network:session():amount_of_alive_players() then
		local mission_not_failed = true -- always will be since we're ingame
		local num_alive_players = managers.network:session():amount_of_alive_players()
		local is_not_in_custody = not Utils:IsInCustody()
		return managers.experience:get_xp_dissected(
			mission_not_failed, num_alive_players, is_not_in_custody
		)
	end
end

function XPperMinute:CreateHUD()
	if managers.hud ~= nil then 
		XPperMinute.hud = managers.hud:script(PlayerBase.PLAYER_INFO_HUD_FULLSCREEN_PD2)
		XPperMinute.text = XPperMinute.hud.panel:text({
			halign = "left",
			vertical = "top",
			hvertical = "top",
			wrap = true,
			align = "left",
			blend_mode = "normal",
			word_wrap = true,
			y = XPperMinute.settings.Y,
			layer = 0,
			text = "0 xp/min",
			font = tweak_data.menu.pd2_small_font,
			font_size = tweak_data.menu.pd2_small_font_size,
			x = XPperMinute.settings.X,
			color = Color.white
		})
	end
end

XPperMinute:Load()