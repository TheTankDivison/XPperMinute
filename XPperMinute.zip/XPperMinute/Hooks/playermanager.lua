
Hooks:PostHook(PlayerManager, "spawn_players", "spawn_players_XPperMinute", function(is_drop_in) --HUDBlackScreen:init(hud) lib\network\base function BaseNetworkSession:spawn_players(is_drop_in)
	XPperMinute:CreateHUD()
	if XPperMinute.hud then
		
		XPperMinute.startTime=Application:time()
		BeardLib:AddUpdater("XPperMinute.Update", XPperMinute.Update, false)
	end
end)

Hooks:PostHook(JobManager, "set_stage_success", "set_stage_success_XPperMinute", function(success) --ElementAiGlobalEvent:on_executed(instigator)
	BeardLib:RemoveUpdater("XPperMinute.Update")
end)