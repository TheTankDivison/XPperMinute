Hooks:PostHook(HUDManager, "_player_hud_layout", "_player_hud_layout_XPperMinute", function(self)
	XPperMinute:CreateHUD()
	if XPperMinute.hud then
		
		XPperMinute.startTime=Application:time()
		BeardLib:AddUpdater("XPperMinute.Update", XPperMinute.Update, false)
	end
end)
