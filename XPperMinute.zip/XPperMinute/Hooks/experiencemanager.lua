
Hooks:PostHook(ExperienceManager, "mission_xp_award", "xp_notifier_after_XPperMinute", function (self, amount)
	--local current_xp = self._global.mission_xp_current and Application:digest_value(self._global.mission_xp_current, false) or 0
	--XPperMinute.totalValue=XPperMinute:get_current_total_xp()
end)


