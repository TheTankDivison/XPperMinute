
Hooks:PostHook(NetworkPeer, "spawn_unit", "spawn_unit_XPperMinute", function(is_drop_in) --HUDBlackScreen:init(hud) lib\network\base function BaseNetworkSession:spawn_players(is_drop_in)
	
end)