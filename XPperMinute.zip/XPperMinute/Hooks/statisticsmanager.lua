Hooks:PostHook(StatisticsManager, "stop_session", "stop_session_XPperMinute", function(data) --ElementAiGlobalEvent:on_executed(instigator)
	BeardLib:RemoveUpdater("XPperMinute.Update")
end)
