Hooks:PostHook(StatisticsManager, "stop_session", "stop_session_XPperMinute", function(data) --ElementAiGlobalEvent:on_executed(instigator)
	BeardLib:RemoveUpdater("XPperMinute.Update")
end)

Hooks:PostHook(JobManager, "set_stage_success", "set_stage_success_XPperMinute", function(success) --ElementAiGlobalEvent:on_executed(instigator)
	BeardLib:RemoveUpdater("XPperMinute.Update")
end)